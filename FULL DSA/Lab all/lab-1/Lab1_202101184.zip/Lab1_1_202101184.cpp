#include <iostream>
using namespace std;
int main()
{	int a,b,c,d,e;
	cout<<"Enter the five values"<<endl;
	cin>>a>>b>>c>>d>>e;
	cout<<"sum of your 5 numbers is = "<<(a+b+c+d+e)<<endl;
	cout<<"average of your 5 numbers is = "<<(a+b+c+d+e)/5<<endl;
}
